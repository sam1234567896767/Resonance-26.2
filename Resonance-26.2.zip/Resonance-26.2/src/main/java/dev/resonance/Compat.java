package dev.resonance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
final class Compat {
    static SoundEvent sound(String path) {
        return SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("resonance", path));
    }
}
