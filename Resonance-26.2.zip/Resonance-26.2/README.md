# Resonance (Soundify alternative)
Client-only, mixin-free Fabric mod. Original code; no Soundify assets used.
Sounds: heartbeat, burning, sneak, hard landing, level up, effect gained, armor equip, bow draw/shot, item swap.

## Build
- Three projects: mc-1.21.11 (JDK 21), mc-26.2 and mc-26.3 (JDK 25). cd into one and run gradle build.
Fill loader/fabric-api versions from fabricmc.net/develop. Jar lands in build/libs. Logo: logo_banner.png.

## Custom sounds
Default sounds reuse vanilla events. To use your own, put .ogg files in
assets/resonance/sounds/ and point sounds.json at them (e.g. {"name":"resonance:heartbeat"}),
or ship them in a resource pack.

## Compatibility
Client-side, no mixins, no server needed; it only reads player state, so it doesn't patch other mods' code.
